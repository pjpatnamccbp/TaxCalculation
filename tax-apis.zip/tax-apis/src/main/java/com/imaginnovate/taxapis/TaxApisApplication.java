package com.imaginnovate.taxapis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxApisApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaxApisApplication.class, args);
	}

}
